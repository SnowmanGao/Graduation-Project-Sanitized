# Pipe Selection Skill

用于从 Aspen 物流 JSON 批量计算设计管径、调用标准管选择器、生成选管编号并输出 Excel。

## 目录结构

```text
pipe_selection_skill/
├─ SKILL.md
├─ README.md
├─ scripts/
│  ├─ batch_select_pipes.py
│  └─ selector.py
├─ config/
│  ├─ pipe_selection_config.json
│  └─ manual_overrides.example.json
├─ examples/
│  └─ aspen_stream.schema.example.json
└─ prompts/
   ├─ pipe_selection_user_prompt.md
   └─ manual_override_prompt.md
```

## 运行

```bash
python scripts/batch_select_pipes.py aspen_stream.json config/pipe_selection_config.json pipe_selection_result.xlsx
```

如果运行环境没有 `artifact_tool`，脚本会自动退回输出 CSV。若在 ChatGPT 文件处理环境中运行，建议使用 `artifact_tool` 输出 xlsx。

## 关键规则

- 汽相基准流速：20 m/s。
- 液相、气液相基准流速：1.5 m/s。
- 初选管径超过 300 mm 时二次选管：汽相 30 m/s，液相/气液相 2.5 m/s。
- 手动覆盖优先，例如 WASTE2-1 取 70 m/s，WASTE2-2 取 50 m/s。
- 温度 < 40 ℃ 不加 30H；温度 >= 40 ℃ 加 30H。
- 压力 > 900 kPa 时最低等级 M1B，否则最低 L1B。
