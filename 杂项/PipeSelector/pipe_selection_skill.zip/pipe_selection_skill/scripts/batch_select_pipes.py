# -*- coding: utf-8 -*-
"""
Aspen 物流批量选管脚本。

用法：
    python scripts/batch_select_pipes.py aspen_stream.json config/pipe_selection_config.json output.xlsx

输入：
    1. Aspen 物流 JSON，顶层 key 为物流名称；
    2. pipe_selection_config.json；
    3. 输出 xlsx 路径。

输出列：
    名称、相态、压力、温度、体积流量、计算管径、实际管径、实际流速、选管编号等。
"""

from __future__ import annotations

import csv
import importlib.util
import json
import math
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

HEADERS = [
    "名称",
    "相态",
    "压力/kPa",
    "温度/℃",
    "体积流量/(m³/h)",
    "设计流速/(m/s)",
    "计算管径/mm",
    "实际管径",
    "实际内径/mm",
    "实际流速/(m/s)",
    "公称直径DN/mm",
    "管道等级",
    "绝热/隔声代号",
    "选管编号",
    "二次调整",
    "备注",
]


def as_float(value: Any) -> Optional[float]:
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError:
            return None
    return None


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def load_select_pipe(selector_path: Path):
    spec = importlib.util.spec_from_file_location("pipe_selector", selector_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载 selector.py: {selector_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore[union-attr]
    if not hasattr(module, "select_pipe"):
        raise RuntimeError("selector.py 中未找到 select_pipe(required_inner_diameter) 函数")
    return module.select_pipe


def infer_phase(stream: Dict[str, Any]) -> str:
    raw_phase = stream.get("相态")
    if isinstance(raw_phase, str) and raw_phase.strip():
        if "气液" in raw_phase or "汽液" in raw_phase:
            return "气液相"
        if "汽" in raw_phase or "气" in raw_phase:
            return "汽相"
        if "液" in raw_phase:
            return "液相"
        return raw_phase.strip()

    vapor_frac = as_float(stream.get("摩尔汽相分率")) or 0.0
    liquid_frac = as_float(stream.get("摩尔液相分率")) or 0.0
    eps = 1e-9
    if vapor_frac > eps and liquid_frac > eps:
        return "气液相"
    if vapor_frac > eps:
        return "汽相"
    if liquid_frac > eps:
        return "液相"
    return "未知"


def required_inner_diameter_mm(volume_flow_m3h: float, velocity_ms: float) -> float:
    q_m3s = volume_flow_m3h / 3600.0
    return math.sqrt(4.0 * q_m3s / (math.pi * velocity_ms)) * 1000.0


def actual_velocity_ms(volume_flow_m3h: float, actual_inner_diameter_mm: float) -> float:
    q_m3s = volume_flow_m3h / 3600.0
    d_m = actual_inner_diameter_mm / 1000.0
    area = math.pi * d_m * d_m / 4.0
    return q_m3s / area


def od_to_dn(od_mm: float, cfg: Dict[str, Any]) -> int:
    mapping = cfg.get("od_to_dn_mm", {})
    # JSON 中 key 是字符串，需要容忍 355.6 这种小数外径。
    for k, v in mapping.items():
        try:
            if abs(float(k) - float(od_mm)) < 1e-9:
                return int(v)
        except ValueError:
            pass
    return int(round(od_mm))


def is_large_pipe(dn: int, od_mm: float, actual_id_mm: float, cfg: Dict[str, Any]) -> bool:
    threshold = float(cfg.get("large_pipe_threshold_mm", 300))
    return dn > threshold or od_mm > threshold or actual_id_mm > threshold


def phase_velocity(phase: str, cfg: Dict[str, Any], mode: str) -> float:
    table = cfg["large_pipe_redesign_velocity_ms"] if mode == "large" else cfg["base_velocity_ms"]
    return float(table.get(phase, table.get("未知", 1.5)))


def choose_pressure_grade(pressure_kpa: Optional[float], cfg: Dict[str, Any]) -> str:
    grades: List[Tuple[str, float]] = [(str(code), float(limit)) for code, limit in cfg["domestic_pressure_grades_mpa"]]
    if pressure_kpa is None:
        required_mpa = 1.0
    else:
        pressure_mpa = pressure_kpa / 1000.0
        if pressure_kpa > 900.0:
            minimum_code = cfg.get("minimum_pressure_grade_over_900_kpa", "M")
        else:
            minimum_code = cfg.get("default_pressure_grade_under_or_equal_900_kpa", "L")
        minimum_mpa = next(limit for code, limit in grades if code == minimum_code)
        required_mpa = max(pressure_mpa, minimum_mpa)

    for code, limit in grades:
        if required_mpa <= limit + 1e-12:
            return code
    return grades[-1][0]


def material_code(name: str, phase: str, override: Dict[str, Any]) -> str:
    if override.get("material_code"):
        return str(override["material_code"])
    upper = name.upper()
    if upper == "EG" or upper.startswith("EG-") or upper.endswith("-EG"):
        return "EG"
    if upper == "PTA" or "PTA" in upper:
        return "PTA"
    if phase == "汽相":
        return "PG"
    if phase == "气液相":
        return "PGL"
    return "PL"


def line_no_for(index: int, cfg: Dict[str, Any], override: Dict[str, Any]) -> str:
    if override.get("line_no"):
        return str(override["line_no"])
    return f"{cfg.get('unit_no', '01')}{index:02d}"


def pipe_string(od_mm: float, thk_mm: float) -> str:
    od = f"{od_mm:g}"
    thk = f"{thk_mm:g}"
    return f"ϕ {od} × {thk} mm"


def round_or_none(value: Optional[float], digits: int) -> Optional[float]:
    if value is None:
        return None
    return round(value, digits)


def select_one(
    name: str,
    stream: Dict[str, Any],
    index: int,
    cfg: Dict[str, Any],
    select_pipe,
) -> List[Any]:
    phase = infer_phase(stream)
    pressure_kpa = as_float(stream.get("压力"))
    temperature_c = as_float(stream.get("温度"))
    volume_flow_m3h = as_float(stream.get("体积流量"))
    override = cfg.get("manual_overrides", {}).get(name, {})

    if volume_flow_m3h is None or volume_flow_m3h <= 0:
        return [
            name, phase, pressure_kpa, temperature_c, volume_flow_m3h,
            None, None, "无有效体积流量", None, None, None,
            None, None, None, "否", "缺少有效体积流量，未选管",
        ]

    # 首轮选管。
    base_v = phase_velocity(phase, cfg, "base")
    calc_d0 = required_inner_diameter_mm(volume_flow_m3h, base_v)
    selected0 = select_pipe(calc_d0)
    if selected0 is None:
        return [
            name, phase, pressure_kpa, temperature_c, volume_flow_m3h,
            base_v, calc_d0, "未找到标准管", None, None, None,
            None, None, None, "否", "selector.py 未返回选管结果",
        ]

    od0, thk0, id0 = selected0
    dn0 = od_to_dn(od0, cfg)
    adjusted = False
    remark_parts: List[str] = []

    # 手动覆盖优先；否则大管径二次选管。
    if override.get("design_velocity_ms") is not None:
        design_v = float(override["design_velocity_ms"])
        adjusted = True
        remark_parts.append(str(override.get("remark", "手动指定设计流速")))
    elif is_large_pipe(dn0, od0, id0, cfg):
        design_v = phase_velocity(phase, cfg, "large")
        adjusted = True
        remark_parts.append("初选管径>300mm，已提高流速重选")
    else:
        design_v = base_v

    calc_d = required_inner_diameter_mm(volume_flow_m3h, design_v)
    selected = select_pipe(calc_d)
    if selected is None:
        return [
            name, phase, pressure_kpa, temperature_c, volume_flow_m3h,
            design_v, calc_d, "未找到标准管", None, None, None,
            None, None, None, "是" if adjusted else "否", "selector.py 未返回选管结果",
        ]

    od, thk, actual_id = selected
    dn = od_to_dn(od, cfg)
    actual_v = actual_velocity_ms(volume_flow_m3h, actual_id)
    pressure_grade = choose_pressure_grade(pressure_kpa, cfg)
    pipe_class = f"{pressure_grade}1{cfg.get('default_pipe_class_material', 'B')}"

    if temperature_c is not None and temperature_c >= float(cfg.get("temperature_no_insulation_threshold_c", 40)):
        insulation_code = str(cfg.get("insulation_code_when_temperature_ge_40c", "30H"))
    else:
        insulation_code = ""

    if pressure_kpa is not None and pressure_kpa > 900.0:
        remark_parts.append("压力>900kPa，最低等级改为M1B")

    code = f"{material_code(name, phase, override)}-{line_no_for(index, cfg, override)}-{dn}-{pipe_class}"
    if insulation_code:
        code += f"-{insulation_code}"

    return [
        name,
        phase,
        round_or_none(pressure_kpa, 3),
        round_or_none(temperature_c, 3),
        round_or_none(volume_flow_m3h, 6),
        round(design_v, 3),
        round(calc_d, 3),
        pipe_string(od, thk),
        round(actual_id, 3),
        round(actual_v, 3),
        dn,
        pipe_class,
        insulation_code,
        code,
        "是" if adjusted else "否",
        "；".join(remark_parts),
    ]


def build_rows(streams: Dict[str, Dict[str, Any]], cfg: Dict[str, Any], selector_path: Path) -> List[List[Any]]:
    select_pipe = load_select_pipe(selector_path)
    return [select_one(name, stream, i, cfg, select_pipe) for i, (name, stream) in enumerate(streams.items(), start=1)]


def write_csv(rows: List[List[Any]], output_path: Path) -> None:
    csv_path = output_path.with_suffix(".csv")
    with csv_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(HEADERS)
        writer.writerows(rows)
    print(f"artifact_tool 不可用，已改为输出 CSV：{csv_path}")


def write_xlsx(rows: List[List[Any]], output_path: Path) -> None:
    try:
        from artifact_tool import Workbook, SpreadsheetFile
    except Exception:
        write_csv(rows, output_path)
        return

    wb = Workbook.create()
    sheet = wb.worksheets.add("选管结果")
    sheet.get_range("A1:P1").merge()
    sheet.get_range("A1").values = [["Aspen 物流批量选管结果"]]
    sheet.get_range("A1").format = {
        "font": {"bold": True, "size": 16, "color": "#FFFFFF"},
        "fill": "#1F4E78",
        "horizontal_alignment": "center",
        "vertical_alignment": "center",
        "row_height": 28,
    }
    data = [HEADERS] + rows
    end_row = len(data) + 2
    sheet.get_range(f"A3:P{end_row}").values = data
    sheet.get_range("A3:P3").format = {
        "font": {"bold": True, "color": "#FFFFFF"},
        "fill": "#5B9BD5",
        "horizontal_alignment": "center",
        "vertical_alignment": "center",
        "wrap_text": True,
        "row_height": 32,
    }
    sheet.get_range(f"A4:P{end_row}").format = {"wrap_text": True, "vertical_alignment": "center"}
    widths = {
        "A": 14, "B": 10, "C": 12, "D": 12, "E": 18, "F": 14, "G": 15, "H": 18,
        "I": 14, "J": 15, "K": 15, "L": 12, "M": 16, "N": 32, "O": 10, "P": 44,
    }
    for col, width in widths.items():
        sheet.get_range(f"{col}:{col}").format.column_width = width
    sheet.freeze_panes.freeze_rows(3)
    sheet.tables.add(f"A3:P{end_row}", True, "PipeSelectionTable")
    SpreadsheetFile.export_xlsx(wb).save(str(output_path))


def main(argv: Iterable[str]) -> int:
    args = list(argv)
    script_dir = Path(__file__).resolve().parent
    skill_dir = script_dir.parent
    input_json = Path(args[0]) if len(args) >= 1 else skill_dir / "examples" / "aspen_stream.schema.example.json"
    config_json = Path(args[1]) if len(args) >= 2 else skill_dir / "config" / "pipe_selection_config.json"
    output_xlsx = Path(args[2]) if len(args) >= 3 else skill_dir / "pipe_selection_result.xlsx"
    selector_py = script_dir / "selector.py"

    streams = load_json(input_json)
    cfg = load_json(config_json)
    rows = build_rows(streams, cfg, selector_py)
    write_xlsx(rows, output_xlsx)
    print(f"完成：共处理 {len(rows)} 条物流；输出：{output_xlsx}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
