# -*- coding: utf-8 -*-
"""
标准管选择器。

接口约定：select_pipe(required_inner_diameter_mm) -> (outer_diameter_mm, wall_thickness_mm, actual_inner_diameter_mm)

说明：
- 这里内置一套常用钢管规格，用于 Skill 包自包含运行；
- 若你已有更完整的 selector.py，可直接用原文件替换本文件；
- 选择原则为：实际内径与所需内径差值的绝对值最小；若差值相同，优先实际内径不小于所需内径。
"""

from __future__ import annotations

from typing import List, Optional, Tuple

# (外径 mm, 壁厚 mm)。可按毕业设计采用的钢管规格表继续增补。
PIPE_SIZES: List[Tuple[float, float]] = [
    (10, 1.0),
    (13, 1.5),
    (17, 1.8),
    (21, 1.8),
    (27, 2.0),
    (34, 1.5),
    (34, 2.0),
    (42, 2.5),
    (48, 2.5),
    (60, 3.0),
    (76, 3.0),
    (89, 3.5),
    (114, 4.0),
    (140, 4.5),
    (168, 5.0),
    (219, 6.0),
    (273, 7.0),
    (325, 8.0),
    (355.6, 8.0),
    (406, 9.0),
    (457, 9.5),
    (508, 10.0),
    (559, 10.0),
    (610, 11.0),
    (711, 12.0),
    (813, 13.0),
    (914, 14.0),
    (1016, 16.0),
    (1016, 35.0),
    (1016, 42.0),
    (1118, 18.0),
    (1219, 20.0),
    (1422, 22.0),
    (1626, 24.0),
    (1626, 88.0),
    (1829, 26.0),
    (2032, 14.0),
    (2032, 28.0),
]


def select_pipe(required_inner_diameter_mm: float) -> Optional[Tuple[float, float, float]]:
    """按实际内径最接近所需内径选管。"""
    if required_inner_diameter_mm <= 0:
        return None

    candidates = []
    for outer_diameter_mm, wall_thickness_mm in PIPE_SIZES:
        actual_inner_diameter_mm = outer_diameter_mm - 2.0 * wall_thickness_mm
        if actual_inner_diameter_mm <= 0:
            continue
        abs_diff = abs(actual_inner_diameter_mm - required_inner_diameter_mm)
        undersized = actual_inner_diameter_mm < required_inner_diameter_mm
        candidates.append((abs_diff, undersized, outer_diameter_mm, wall_thickness_mm, actual_inner_diameter_mm))

    if not candidates:
        return None

    candidates.sort(key=lambda x: (x[0], x[1]))
    _, _, outer_diameter_mm, wall_thickness_mm, actual_inner_diameter_mm = candidates[0]
    return outer_diameter_mm, wall_thickness_mm, actual_inner_diameter_mm


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        raise SystemExit("用法：python selector.py <计算内径mm>")
    d = float(sys.argv[1])
    print(select_pipe(d))
